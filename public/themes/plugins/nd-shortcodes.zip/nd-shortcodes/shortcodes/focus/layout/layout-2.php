<?php
  

$str .= '

	<!--START FOCUS-->
  	<div class="nd_options_section nd_options_text_align_center nd_options_position_relative '.$nd_options_class.' ">


  		<div class="nd_options_fadein_fadeout nd_options_section nd_options_position_relative nd_options_margin_top_15">

  			<img alt="" class="nd_options_filter_blur_5 nd_options_transition_all_08_ease nd_options_section nd_options_border_radius_3 nd_options_box_shadow_0_7_20_000_015" src="'.$nd_options_image_src[0].'">

  			<div class="nd_options_position_absolute nd_options_height_100_percentage nd_options_width_100_percentage nd_options_fadein">
  				<div class="nd_options_position_absolute nd_options_display_table nd_options_height_100_percentage nd_options_width_100_percentage">
  					
  					<div class="nd_options_display_table_cell nd_options_vertical_align_middle">
	                    
  						<a style="background-color:'.$nd_options_color.';" rel="'.$nd_options_link_rel.'" target="'.$nd_options_link_target.'" href="'.$nd_options_link_url.'" class=" nd_options_display_inline_block nd_options_line_height_16 nd_options_box_sizing_border_box  nd_options_color_white nd_options_first_font nd_options_padding_10_20 nd_options_border_radius_3">
  							'.$nd_options_link_title.'
  						</a>

	                </div>

  				</div>
  			</div>

  		</div>
  		

  		<div class="nd_options_section nd_options_height_20"></div>


  		<div class="nd_options_display_table nd_options_margin_auto">

  			<div class="nd_options_display_table_cell nd_options_vertical_align_middle">
  				<a rel="'.$nd_options_link_rel.'" target="'.$nd_options_link_target.'" href="'.$nd_options_link_url.'"><h3 class="nd_options_margin_10"><strong>'.$nd_options_title.'</strong></h3></a>
  			</div>
  			
  			<div class="nd_options_display_table_cell nd_options_vertical_align_middle">
  				<a rel="'.$nd_options_link_rel.'" target="'.$nd_options_link_target.'" href="'.$nd_options_link_url.'">
  					<span style="background-color:'.$nd_options_color.';" class=" nd_options_display_inline_block  nd_options_margin_10 nd_options_color_white nd_options_first_font nd_options_padding_5_8 nd_options_border_radius_3 nd_options_font_size_13">
	  		  		'.$nd_options_subtitle.'
	  				</span>
	  			</a>
  			</div>

  		</div>


  	</div>
  	<!--END FOCUS-->
	

   ';
