<?php

  
$str .= '

  <!--START team-->
  <div class="nd_options_section nd_options_border_1_solid_grey  nd_options_text_align_center '.$nd_options_class.' ">

      <div style="background-color:'.$nd_options_color_2.';" class="nd_options_section nd_options_padding_20 nd_options_box_sizing_border_box">
          <h4 class="nd_options_color_white">'.$nd_options_title.'</h4>
      </div>

      <img class="nd_options_section" alt="" src="'.$nd_options_image_src[0].'">

       <div style="background-color:'.$nd_options_color.';" class="nd_options_section nd_options_padding_20 nd_options_box_sizing_border_box">
          <h5 class="nd_options_color_white">'.$nd_options_role.'</h5>
      </div>
      
      <div class="nd_options_section">
          <div class="nd_options_section nd_options_padding_20 nd_options_box_sizing_border_box">
              <p>'.$nd_options_description.'</p>
          </div>
      </div>

  </div>
  <!--END team-->


   ';