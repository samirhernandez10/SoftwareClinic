<?php

  
$str .= '

    <div class="nd_options_section nd_options_bg_white nd_options_border_radius_15 '.$nd_options_class.' ">
                                        
        <div class="nd_options_section nd_options_box_sizing_border_box nd_options_padding_20 nd_options_text_align_center">
            
            <img alt="" width="40" src="'.$nd_options_image_src[0].'">
            <div class="nd_options_section nd_options_height_5"></div>
            <h1 class="nd_options_font_size_40">'.$nd_options_title.'</h1>
            <div class="nd_options_section nd_options_height_10"></div>
            <h4 class="nd_options_color_grey nd_options_font_size_12 nd_options_text_transform_uppercase nd_options_letter_spacing_3 nd_options_second_font nd_options_font_weight_lighter">'.$nd_options_description.'</h4>

        </div>

    </div>

  ';
