<?php


//START LAYOUT
$nd_elements_result .= '
<div class="nd_elements_section nd_elements_marquee_component">

	<marquee class="nd_elements_section">
        <span class="nd_elements_marquee_label nd_elements_display_inline_block">'.$marquee_label.'</span>
        <span class="nd_elements_marquee_content">'.$marquee_content.'</span>
    </marquee>
	
</div>';
//END LAYOUT