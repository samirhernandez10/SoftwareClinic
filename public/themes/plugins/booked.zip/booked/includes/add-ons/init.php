<?php

include( 'calendar-feeds/booked-calendar-feeds.php' );
include( 'frontend-agents/booked-frontend-agents.php' );
include( 'woocommerce-payments/booked-woocommerce-payments.php' );
