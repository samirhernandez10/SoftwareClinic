<?php

  
$str .= '

  <style>
    .nd_options_focus_number_2_vertical_line:after{content:"";width: 0px;height: 100%;position: absolute;left: 40px;z-index: 9;border-left: 2px dashed #f1f1f1;}
  </style>

  <!--START FOCUS NUMBER-->
  <div class=" '.$nd_options_class.' nd_options_section nd_options_focus_number_2_vertical_line nd_options_position_relative nd_options_box_sizing_border_box">
    
    <p style="background-color:'.$nd_options_bg_color.';" class="nd_options_first_font nd_options_z_index_99 nd_options_border_radius_20 nd_options_padding_5_10 nd_options_box_sizing_border_box nd_options_color_white nd_options_text_align_center nd_options_width_80 nd_options_position_absolute nd_options_top_15 nd_options_left_20 nd_options_font_size_17">
      '.$nd_options_number.'
    </p>

    <div class="nd_options_section nd_options_padding_left_120 nd_options_box_sizing_border_box">
        <h3 class="nd_options_margin_top_20">'.$nd_options_title.'</h3>                        
        <div class="nd_options_section nd_options_height_20"></div>
        <p class="nd_options_margin_bottom_10">'.$nd_options_description.'</p>
    </div>

  </div>
  <!--END FOCUS NUMBER-->

   ';