<div id="nd_options_woocommerce_archives_header_img_layout_6" class="nd_options_section nd_options_bg_greydark nd_options_background_size_cover <?php echo esc_attr($nd_options_customizer_woocommerce_archive_products_header_image_position); ?>" style="background-image:url(<?php echo esc_url($nd_options_customizer_woocommerce_archive_products_header_image_src); ?>);">

    <div class="nd_options_section nd_options_bg_greydark_alpha_3">

        <!--start nd_options_container-->
        <div class="nd_options_container nd_options_clearfix">


            <div id="nd_options_woo_archive_header_image_space_top" class="nd_options_section nd_options_height_110"></div>

            <div class="nd_options_section nd_options_padding_15 nd_options_box_sizing_border_box nd_options_text_align_center">

                <h1 class="nd_options_color_white nd_options_font_weight_normal nd_options_first_font">
                    <span class="nd_options_display_block"><?php echo esc_html(woocommerce_page_title()); ?></span>
                    <div class="nd_options_section"><span class="nd_options_bg_white nd_options_width_80 nd_options_height_4 nd_options_display_inline_block"></span></div>
                </h1>

            </div>

            <div id="nd_options_woo_archive_header_image_space_bottom" class="nd_options_section nd_options_height_110"></div>

        </div>
        <!--end container-->

    </div>

</div>