<?php

  
$str .= '
	'.$nd_options_align_top.'
	<a style="border: '.$nd_options_border_width.'px solid '.$nd_options_border_color.'; border-radius:'.$nd_options_border_radius.'px; letter-spacing:'.$nd_options_letter_spacing.'px; line-height:'.$nd_options_font_size.'px; font-size:'.$nd_options_font_size.'px; background-color:'.$nd_options_bg_color.'; padding:'.$nd_options_padding.'; margin:'.$nd_options_margin.'; color:'.$nd_options_text_color.';" rel="'.$nd_options_link_rel.'" '.$nd_options_link_target_output.' href="'.$nd_options_link_url.'" class="nicdark_display_inline_block '.$nd_options_align_class.' '.$nd_options_font_weight.' '.$nd_options_font_family.' '.$nd_options_class.' ">'.$nd_options_link_title.'</a>
	'.$nd_options_align_bottom.'
';