<?php

  
$str .= '

  <!--START TESTIMONIAL-->
  <div class="nd_options_section '.$nd_options_class.'">
                                            
    <div style="background-color:'.$nd_options_color.';" class="nd_options_section nd_options_padding_40 nd_options_border_radius_3 nd_options_text_align_center nd_options_box_sizing_border_box">
      <p class="nd_options_color_white nd_options_margin_0_important">'.$nd_options_testimonial.'</p>
    </div> 
    <div class="nd_options_section ">
      <div style="border-top-color:'.$nd_options_color.';" class="nd_options_margin_auto nd_options_height_0 nd_options_width_0 nd_options_border_style_solid nd_options_border_color_transparent nd_options_border_width_15 nd_options_border_bottom_width_0"></div> 
    </div>
    <div class="nd_options_section nd_options_height_20 "></div>


    <div class="nd_options_section nd_options_text_align_center">
      <img width="80" class="nd_options_border_radius_100_percentage" src="'.$nd_options_image_src[0].'"> 
      <div class="nd_options_section nd_options_height_20 "></div>
      <h4 class="nd_options_margin_0_important">'.$nd_options_name.'</h4>
      <div class="nd_options_section nd_options_height_10 "></div>
      <p class="nd_options_margin_0_important">'.$nd_options_role.'</p>
    </div>  


  </div>
  <!--END TESTIMONIAL-->

   ';