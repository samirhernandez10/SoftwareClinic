<?php

  
$str .= '

  <!--START FOCUS-->
  <div class="nd_options_section nd_options_position_relative '.$nd_options_class.' ">
                      
      <img alt="" class="nd_options_section" src="'.$nd_options_image_src[0].'">

      <div class="nd_options_bg_greydark_alpha_gradient nd_options_position_absolute nd_options_left_0 nd_options_height_100_percentage nd_options_width_100_percentage nd_options_padding_30 nd_options_box_sizing_border_box">
          
          <div class="nd_options_display_table nd_options_width_100_percentage nd_options_height_100_percentage nd_options_text_align_center">
          
              <div class="nd_options_display_table_cell nd_options_vertical_align_bottom">
            
                <a rel="'.$nd_options_link_rel.'" title="'.$nd_options_link_title.'" target="'.$nd_options_link_target.'" class="nd_options_color_white" href="'.$nd_options_link_url.'">
                  <h4 class="nd_options_margin_0_important nd_options_color_white nd_options_color_white nd_options_second_font nd_options_letter_spacing_3 nd_options_font_weight_lighter">
                    '.$nd_options_title.'
                  </h4>
                </a>

              </div>

          </div>

      </div>

  </div>
  <!--END FOCUS-->
                

   ';