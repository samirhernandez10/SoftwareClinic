<div class="nd_options_section nd_options_background_size_cover <?php echo esc_attr($nd_options_meta_box_woocommerce_header_img_position); ?>" style="background-image:url(<?php echo esc_url($nd_options_meta_box_woocommerce_header_img); ?>);">

    <div class="nd_options_section nd_options_bg_greydark_alpha_gradient_2">

        <!--start nd_options_container-->
        <div class="nd_options_container nd_options_clearfix">


            <div class="nd_options_section nd_options_height_200"></div>

            <div class="nd_options_section nd_options_padding_15 nd_options_box_sizing_border_box">

                <strong class="nd_options_color_white nd_options_font_size_60 nd_options_font_size_40_all_iphone nd_options_line_height_40_all_iphone nd_options_first_font"><?php echo esc_html($nd_options_meta_box_woocommerce_header_img_title); ?></strong>
                <div class="nd_options_section nd_options_height_20"></div>

            </div>

        </div>
        <!--end container-->

    </div>

</div>