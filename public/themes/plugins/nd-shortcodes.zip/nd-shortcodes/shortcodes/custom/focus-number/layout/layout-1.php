<?php

  
$str .= '

  <!--START FOCUS NUMBER-->
  <div style="background-color:'.$nd_options_bg_color.';" class=" '.$nd_options_class.' nd_options_section nd_options_position_relative nd_options_padding_20 nd_options_box_sizing_border_box">
    
    <span style="color:'.$nd_options_text_color.';" class="nd_options_bg_white_alpha_1 nd_options_display_table nd_options_text_align_center nd_options_height_50 nd_options_width_50 nd_options_position_absolute nd_options_top_20 nd_options_left_20 nd_options_font_size_17">
      <i class="nd_options_display_table_cell nd_options_vertical_align_middle">'.$nd_options_number.'</i>
    </span>

    <div class="nd_options_section nd_options_padding_left_70 nd_options_box_sizing_border_box">
        <h4 style="color:'.$nd_options_text_color.';">'.$nd_options_title.'</h4>                        
        <div class="nd_options_section nd_options_height_20"></div>
        <p style="color:'.$nd_options_text_color.';">'.$nd_options_description.'</p>
    </div>

  </div>
  <!--END FOCUS NUMBER-->

   ';